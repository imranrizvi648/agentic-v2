"use client";

import { useEffect, useRef } from "react";
import Link from "next/link";

// ─── Data ────────────────────────────────────────────────────────────────────

const hero = {
  headline: "When Off-the-Shelf Won't Fit, We Engineer It From First Principles.",
  highlight: "We Engineer It From First Principles.",
  sub: "We design and ship custom, tool-using agents and multi-agent systems that plan, act and verify \u2014 orchestrated for reliability, wrapped in the controls an enterprise requires, built on the model that fits your environment.",
  cta1: "Discuss Your Agent Requirements",
  cta2: "See Our Build Stack",
  trustLabel: "Built on",
  badges: ["LangGraph", "FastAPI", "Claude / GPT / Gemini", "OCI & Azure"],
};

const overview = {
  heading: "Agents Built for Your Workflows \u2014 Not Built Around Someone Else's",
  lead: "Every enterprise has workflows that don't fit the template. The approval chain that spans four systems. The reconciliation that needs to reason across two data sources. The onboarding process that branches across seven conditions. We build the agents that handle these.",
  body: "Our custom agent development practice covers the full engineering spectrum \u2014 from single task agents to multi-agent orchestration systems with planning, tool use, retrieval, verification and human-in-the-loop controls. Model-flexible. Enterprise-hardened. Shipped to production.",
  stats: [
    { val: "Multi", label: "Agent orchestration with LangGraph" },
    { val: "4+", label: "LLM families supported" },
    { val: "HITL", label: "Human review on every critical path" },
    { val: "RAG", label: "Retrieval over your own data" },
  ],
  cards: [
    { title: "Multi-Agent Orchestration", body: "LangGraph-based orchestration with defined agent roles, tool routing, state management and failure handling." },
    { title: "Tool & System Integration", body: "Agents that use your real tools \u2014 ERP APIs, databases, search, email, calendars, external services." },
    { title: "Retrieval-Augmented Reasoning", body: "RAG pipelines over your own documents, policies and data \u2014 grounded responses, not hallucinated ones." },
    { title: "Model-Flexible Architecture", body: "Built to run on Anthropic Claude, OpenAI GPT, Google Gemini, OCI or Azure models \u2014 your choice, your cost profile." },
  ],
};

const benefits = [
  { icon: "\ud83d\udd27", title: "Fits your exact workflow", body: "No compromises on edge cases, approval structures or data formats. The agent is designed for your process, not the other way around." },
  { icon: "\ud83c\udff0", title: "Enterprise controls from day one", body: "Guardrails, approval gates, human-in-the-loop checkpoints and retry logic are not add-ons \u2014 they are part of the initial design." },
  { icon: "\ud83e\udde0", title: "Reasons over your own data", body: "RAG pipelines give agents access to your policies, historical records and domain knowledge \u2014 no general-knowledge hallucination risk." },
  { icon: "\ud83d\udd00", title: "Multi-agent coordination", body: "Complex workflows split across specialised agents \u2014 each owns its domain, passes context cleanly and verifies before acting." },
  { icon: "\ud83d\udcc0", title: "Model cost is your call", body: "We build model-flexible architectures. As models improve and costs drop, your agent runs on a more capable and cheaper model without re-engineering." },
  { icon: "\ud83d\udce6", title: "Fully owned by you", body: "The code is yours. Deployed on your infrastructure. No vendor dependency, no per-seat licensing and no black-box behaviour." },
];

const features = [
  { num: "01", title: "LangGraph multi-agent orchestration", body: "Directed graph-based agent workflows with explicit state, conditional routing and cycle handling \u2014 production-grade, not experimental." },
  { num: "02", title: "FastAPI backend architecture", body: "Async FastAPI services for agent execution, tool integration and external API calls \u2014 high-performance, maintainable, containerised." },
  { num: "03", title: "Vector search and RAG pipelines", body: "pgvector or dedicated vector stores for document retrieval \u2014 giving agents access to your proprietary knowledge base." },
  { num: "04", title: "Tool use and function calling", body: "Agents that call real APIs, run database queries, read files, send emails and update records \u2014 not just generate text." },
  { num: "05", title: "Human-in-the-loop checkpoints", body: "Configurable approval gates, retry logic and verification steps \u2014 so critical actions always go through the right human before execution." },
  { num: "06", title: "LLM model flexibility", body: "Anthropic Claude, OpenAI GPT-4o, Google Gemini, OCI GenAI and Azure OpenAI \u2014 selected for your accuracy, cost and data-residency requirements." },
  { num: "07", title: "Gunicorn multi-worker deployment", body: "Production-grade WSGI serving with Gunicorn, Redis for state/caching and Celery for background task orchestration." },
  { num: "08", title: "Full observability", body: "Logging of every agent action, tool call, model response and decision point \u2014 with monitoring dashboards and alerting from day one." },
];

const process = [
  { num: "01", title: "Requirements", body: "We map the workflow, identify every tool and system the agent needs to use, and define the boundaries between autonomous action and human review." },
  { num: "02", title: "Architecture", body: "Agent graph design, tool schema definition, RAG pipeline architecture and model selection \u2014 documented before a line of code." },
  { num: "03", title: "Build & Integrate", body: "Agent development in iterative sprints, tested against your real data sources and real integrations from the first sprint." },
  { num: "04", title: "Harden & Evaluate", body: "Adversarial testing, edge-case handling, guardrail validation and performance benchmarking before go-live." },
  { num: "05", title: "Deploy & Operate", body: "Production deployment with monitoring, alerting and ongoing optimisation. You own the code; we provide the expertise." },
];

const whyUs = {
  heading: "Engineering Depth That Generic AI Firms Can't Match",
  points: [
    { title: "We build from first principles", body: "No pre-built templates, no off-the-shelf connectors. Every agent is engineered for your specific workflow, data model and integration landscape." },
    { title: "Model-agnostic by architecture", body: "Your agent is not locked to one LLM provider. We build the architecture so you can switch models as the landscape evolves \u2014 without rebuilding." },
    { title: "Production is the only standard", body: "We do not build demos. Every agent we ship is tested against real data, real integrations and real edge cases before it touches production." },
    { title: "The code is yours", body: "Full code ownership, clean documentation and structured handover. No vendor lock-in, no black boxes, no ongoing licensing dependency." },
  ],
  box: {
    heading: "Model-Flexible. Enterprise-Hardened.",
    body: "Built to run on the model that fits your requirements today \u2014 and to switch as the landscape improves, without a rebuild.",
    stats: [
      { val: "4+", label: "LLM families supported natively" },
      { val: "100%", label: "Code ownership \u2014 no lock-in" },
      { val: "HITL", label: "Human controls on every critical path" },
    ],
  },
};

const faqs = [
  { q: "How is a custom agent different from using an AI platform or SaaS product?", a: "A SaaS AI product is built for the average use case. A custom agent is engineered for yours \u2014 your data model, your approval logic, your integration landscape and your governance requirements. The edge cases that break generic products are handled because we designed for them." },
  { q: "Which LLM should we use?", a: "We recommend the model that fits your accuracy requirements, data-residency constraints and cost profile \u2014 not the model we have a commercial arrangement with. We have production experience with Anthropic Claude, OpenAI GPT-4o, Google Gemini and Oracle OCI GenAI." },
  { q: "Do we need a data team or AI team on our side?", a: "No. We handle architecture, build, integration, deployment and operations. Your team defines the business requirements and reviews outputs. We provide the engineering depth \u2014 you stay focused on the outcome." },
  { q: "Can an agent you build be extended later by our internal team?", a: "Yes. We write clean, documented code with a clear architecture. We also provide a structured handover and can train your team to extend and maintain the agent. There are no lock-in mechanisms." },
];

const cta = {
  heading: "Describe the Workflow That Doesn't Fit Any Off-the-Shelf Product.",
  body: "We've heard it before. Tell us what you need \u2014 the process, the systems involved and the outcome you're after. We'll tell you how we would engineer it, what the build looks like and what you should expect from a first pilot.",
  cta1: "Start the Technical Conversation",
  cta2: "See Example Agent Architectures",
};

const relatedServices = [
  { title: "Enterprise ERP & CRM-Native AI Integration", slug: "/services/erp-crm-ai-integration", number: "02" },
  { title: "Conversational AI & Enterprise Copilots", slug: "/services/conversational-ai-enterprise-copilots", number: "05" },
  { title: "AI Governance, Security & MLOps", slug: "/services/ai-governance-security-mlops", number: "09" },
];

// ─── Helpers ─────────────────────────────────────────────────────────────────

function SectionLabel({ text }) {
  return (
    <div className="flex items-center gap-3 mb-4">
      <span className="w-6 h-0.5 bg-indigo-500" />
      <span className="text-xs font-black uppercase tracking-widest text-indigo-600">{text}</span>
    </div>
  );
}

// ─── Component ───────────────────────────────────────────────────────────────

export default function CustomAiAgentDevelopmentContent() {
  const [before, after] = hero.headline.split(hero.highlight);
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    let raf, W, H;
    let mouse = { x: -999, y: -999 };

    const resize = () => {
      W = canvas.width  = canvas.offsetWidth;
      H = canvas.height = canvas.offsetHeight;
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);

    const onMouse = (e) => {
      const r = canvas.getBoundingClientRect();
      mouse.x = e.clientX - r.left;
      mouse.y = e.clientY - r.top;
    };
    const onLeave = () => { mouse.x = -999; mouse.y = -999; };
    canvas.addEventListener("mousemove", onMouse);
    canvas.addEventListener("mouseleave", onLeave);

    /* ── Bezier lines ── */
    const COUNT = 24;
    const buildLines = () =>
      Array.from({ length: COUNT }, (_, i) => {
        const t = i / (COUNT - 1);
        return {
          sx:   W * (0.42 + t * 0.62), sy: 0,
          ex:   W * (-0.08 + t * 0.55), ey: H * (0.82 + t * 0.22),
          cp1x: W * (0.52 + t * 0.32), cp1y: H * (0.06 + t * 0.04),
          cp2x: W * (0.28 + t * 0.28), cp2y: H * (0.52 + t * 0.18),
          alpha: 0.04 + t * 0.07,
          width: 0.4 + t * 0.25,
        };
      });
    let lines = buildLines();
    const roLines = new ResizeObserver(() => { lines = buildLines(); });
    roLines.observe(canvas);

    /* ── Palette ── */
    const PALETTE = [
      [148, 130, 255],
      [98,  94,  255],
      [180, 170, 255],
      [80,  120, 255],
      [200, 190, 255],
      [255, 255, 255],
      [120, 200, 255],
    ];

    /* ── Particle class ── */
    class P {
      constructor(init) { this.spawn(init); }
      spawn(init = false) {
        this.x    = Math.random() * W;
        this.y    = init ? Math.random() * H : H + 8;
        const speed = Math.random() * 1.8 + 0.6;
        const angle = -Math.PI / 2 + (Math.random() - 0.5) * 0.9;
        this.vx   = Math.cos(angle) * speed;
        this.vy   = Math.sin(angle) * speed;
        this.col  = PALETTE[Math.floor(Math.random() * PALETTE.length)];
        this.life  = 1;
        this.decay = Math.random() * 0.006 + 0.003;
        const rnd = Math.random();
        if (rnd < 0.08) {
          this.type = "orb";
          this.r    = Math.random() * 5 + 3;
          this.decay *= 0.4;
          this.pulse = Math.random() * Math.PI * 2;
          this.pulseSpeed = Math.random() * 0.06 + 0.03;
        } else if (rnd < 0.22) {
          this.type = "star";
          this.r    = Math.random() * 2 + 1.2;
          this.rot  = Math.random() * Math.PI;
          this.rotSpeed = (Math.random() - 0.5) * 0.08;
        } else {
          this.type = "dot";
          this.r    = Math.random() * 1.4 + 0.3;
          this.vx   *= 1.4;
          this.vy   *= 1.4;
        }
      }
      update() {
        const dx = this.x - mouse.x;
        const dy = this.y - mouse.y;
        const d2 = dx * dx + dy * dy;
        if (d2 < 160 * 160) {
          const d = Math.sqrt(d2);
          const f = (160 - d) / 160;
          this.vx += (dx / d) * f * 1.2;
          this.vy += (dy / d) * f * 1.2;
        }
        const spd = Math.sqrt(this.vx * this.vx + this.vy * this.vy);
        if (spd > 4) { this.vx = (this.vx / spd) * 4; this.vy = (this.vy / spd) * 4; }
        this.x  += this.vx;
        this.y  += this.vy;
        this.vx *= 0.97;
        this.vy *= 0.97;
        this.life -= this.decay;
        if (this.type === "orb")  this.pulse += this.pulseSpeed;
        if (this.type === "star") this.rot   += this.rotSpeed;
        if (this.life <= 0 || this.y < -12 || this.x < -20 || this.x > W + 20) this.spawn();
      }
      draw() {
        const [r, g, b] = this.col;
        const a = this.life;
        ctx.save();
        if (this.type === "orb") {
          const pr = this.r * (1 + 0.3 * Math.sin(this.pulse));
          ctx.globalAlpha = a * 0.6;
          ctx.shadowBlur  = 20;
          ctx.shadowColor = `rgb(${r},${g},${b})`;
          const grd = ctx.createRadialGradient(this.x, this.y, 0, this.x, this.y, pr * 3);
          grd.addColorStop(0,   `rgba(${r},${g},${b},1)`);
          grd.addColorStop(0.4, `rgba(${r},${g},${b},0.5)`);
          grd.addColorStop(1,   `rgba(${r},${g},${b},0)`);
          ctx.fillStyle = grd;
          ctx.beginPath();
          ctx.arc(this.x, this.y, pr * 3, 0, Math.PI * 2);
          ctx.fill();
        } else if (this.type === "star") {
          ctx.globalAlpha = a * 0.85;
          ctx.shadowBlur  = 8;
          ctx.shadowColor = `rgb(${r},${g},${b})`;
          ctx.fillStyle   = `rgba(${r},${g},${b},1)`;
          ctx.translate(this.x, this.y);
          ctx.rotate(this.rot);
          ctx.beginPath();
          const s = this.r;
          for (let k = 0; k < 8; k++) {
            const ang = (k * Math.PI) / 4;
            const rad = k % 2 === 0 ? s : s * 0.4;
            k === 0
              ? ctx.moveTo(Math.cos(ang) * rad, Math.sin(ang) * rad)
              : ctx.lineTo(Math.cos(ang) * rad, Math.sin(ang) * rad);
          }
          ctx.closePath();
          ctx.fill();
        } else {
          ctx.globalAlpha = a * 0.9;
          ctx.shadowBlur  = 6;
          ctx.shadowColor = `rgb(${r},${g},${b})`;
          ctx.fillStyle   = `rgba(${r},${g},${b},1)`;
          ctx.beginPath();
          ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      }
    }

    const particles = Array.from({ length: 130 }, () => new P(true));

    /* ── Connection lines ── */
    const drawLinks = () => {
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const d2 = dx * dx + dy * dy;
          if (d2 < 75 * 75) {
            const d = Math.sqrt(d2);
            const alpha = (1 - d / 75) * 0.18 * Math.min(particles[i].life, particles[j].life);
            ctx.save();
            ctx.globalAlpha = alpha;
            const [r1,g1,b1] = particles[i].col;
            const [r2,g2,b2] = particles[j].col;
            const lg = ctx.createLinearGradient(particles[i].x, particles[i].y, particles[j].x, particles[j].y);
            lg.addColorStop(0, `rgb(${r1},${g1},${b1})`);
            lg.addColorStop(1, `rgb(${r2},${g2},${b2})`);
            ctx.strokeStyle = lg;
            ctx.lineWidth   = 0.5;
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.stroke();
            ctx.restore();
          }
        }
      }
    };

    let tick = 0;
    const draw = () => {
      tick++;
      ctx.globalCompositeOperation = "source-over";
      ctx.fillStyle = "rgba(26,25,77,0.55)";
      ctx.fillRect(0, 0, W, H);

      const depth = ctx.createLinearGradient(0, 0, W, H);
      depth.addColorStop(0,   "rgba(6,5,28,0.3)");
      depth.addColorStop(0.5, "rgba(26,25,77,0)");
      depth.addColorStop(1,   "rgba(10,8,38,0.25)");
      ctx.fillStyle = depth;
      ctx.fillRect(0, 0, W, H);

      const glow = ctx.createRadialGradient(W * 0.9, 0, 0, W * 0.9, 0, W * 0.52);
      glow.addColorStop(0,   "rgba(98,94,255,0.14)");
      glow.addColorStop(0.5, "rgba(98,94,255,0.05)");
      glow.addColorStop(1,   "rgba(98,94,255,0)");
      ctx.fillStyle = glow;
      ctx.fillRect(0, 0, W, H);

      drawLinks();
      particles.forEach(p => { p.update(); p.draw(); });

      lines.forEach((l, i) => {
        const drift = Math.sin(tick * 0.004 + i * 0.38) * (H * 0.006);
        ctx.save();
        ctx.globalAlpha = l.alpha;
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth   = l.width;
        ctx.lineCap     = "round";
        ctx.beginPath();
        ctx.moveTo(l.sx, l.sy);
        ctx.bezierCurveTo(l.cp1x, l.cp1y + drift, l.cp2x, l.cp2y + drift * 0.5, l.ex, l.ey);
        ctx.stroke();
        ctx.restore();
      });

      raf = requestAnimationFrame(draw);
    };
    draw();

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      roLines.disconnect();
      canvas.removeEventListener("mousemove", onMouse);
      canvas.removeEventListener("mouseleave", onLeave);
    };
  }, []);

  return (
    <main>

      {/* ── Hero (Canvas Animated + Premium Dark Theme) ───────────────────────── */}
      <section className="relative w-full min-h-[85vh] bg-[#1a194d] overflow-hidden flex items-center font-sans pt-32 pb-20">
        <canvas
          ref={canvasRef}
          aria-hidden="true"
          className="absolute inset-0 w-full h-full block"
        />

        {/* Left vignette */}
        <div
          aria-hidden="true"
          className="absolute inset-0 pointer-events-none bg-gradient-to-r from-[rgba(18,16,60,0.85)] via-[rgba(18,16,60,0.55)] to-transparent"
        />

        {/* Bottom fade */}
        <div
          aria-hidden="true"
          className="absolute bottom-0 left-0 w-full h-24 bg-gradient-to-t from-[rgba(26,25,77,0.85)] to-transparent pointer-events-none"
        />

        {/* Hero Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-6 w-full">
          <h1 className="text-4xl md:text-5xl lg:text-[3.25rem] font-extrabold text-white leading-[1.1] tracking-tight max-w-4xl mb-6">
            {before}<span className="text-[#9482ff]">{hero.highlight}</span>{after}
          </h1>
          <p className="text-base sm:text-lg leading-relaxed text-white/70 max-w-2xl mb-10">
            {hero.sub}
          </p>
          
          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 mb-12">
            <Link href="#" className="inline-flex items-center justify-center gap-2 bg-[#625eff] text-white font-bold text-sm px-6 py-3.5 rounded-md hover:bg-[#4b47e6] transition-colors shadow-lg shadow-indigo-950/50">
              {hero.cta1} →
            </Link>
            <Link href="#" className="inline-flex items-center justify-center gap-2 bg-white/10 backdrop-blur-sm text-white font-bold text-sm px-6 py-3.5 rounded-md border border-white/20 hover:bg-white/20 hover:border-white/40 transition-all">
              {hero.cta2}
            </Link>
          </div>

          {/* Badges */}
          <div className="flex flex-wrap items-center gap-3">
            <span className="text-xs font-semibold text-white/40 uppercase tracking-wide">
              {hero.trustLabel}
            </span>
            {hero.badges.map((b) => (
              <span key={b} className="text-xs font-semibold text-white/90 bg-white/5 border border-white/10 px-3 py-1.5 rounded-full backdrop-blur-sm">
                {b}
              </span>
            ))}
          </div>
        </div>

        {/* Bottom accent line */}
        <div
          aria-hidden="true"
          className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-[rgba(98,94,255,0.45)] to-transparent z-10 pointer-events-none"
        />
      </section>

      {/* ── Overview ─────────────────────────────────────────── */}
      <section className="bg-white py-20 border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-14 items-start">
            <div className="lg:col-span-7">
              <SectionLabel text="Service Overview" />
              <h2 className="text-3xl md:text-4xl font-extrabold text-slate-900 leading-tight tracking-tight mb-5">
                {overview.heading}
              </h2>
              <p className="text-base text-indigo-700 font-semibold leading-relaxed mb-4">{overview.lead}</p>
              <p className="text-sm text-slate-500 leading-relaxed mb-8">{overview.body}</p>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {overview.stats.map((s) => (
                  <div key={s.label} className="bg-indigo-50 border border-indigo-100 rounded-xl p-4">
                    <div className="text-2xl font-extrabold text-indigo-600 leading-none mb-1">{s.val}</div>
                    <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide leading-tight">{s.label}</div>
                  </div>
                ))}
              </div>
            </div>
            <div className="lg:col-span-5 grid grid-cols-1 gap-3">
              {overview.cards.map((c) => (
                <div key={c.title} className="bg-slate-50 rounded-xl p-5 border border-slate-100 hover:border-indigo-200 transition-colors">
                  <h4 className="text-xs font-black uppercase tracking-wide text-slate-800 mb-2">{c.title}</h4>
                  <p className="text-sm text-slate-500 leading-relaxed">{c.body}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── Benefits ─────────────────────────────────────────── */}
      <section className="bg-slate-50 py-20 border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-6">
          <SectionLabel text="Benefits" />
          <h2 className="text-3xl md:text-4xl font-extrabold text-slate-900 tracking-tight mb-12 max-w-2xl leading-tight">
            What Changes When Agents Handle This Work
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-0 border border-slate-200 rounded-2xl overflow-hidden">
            {benefits.map((b, i) => (
              <div
                key={b.title}
                className={`bg-white p-7 hover:bg-indigo-50/30 transition-colors ${i % 3 !== 2 ? "lg:border-r border-slate-100" : ""} ${i < 3 ? "border-b border-slate-100" : ""}`}
              >
                <span className="text-2xl mb-4 block">{b.icon}</span>
                <h3 className="text-sm font-black text-slate-900 mb-2 leading-snug">{b.title}</h3>
                <p className="text-xs text-slate-500 leading-relaxed">{b.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Features ─────────────────────────────────────────── */}
      <section className="bg-white py-20 border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-6">
          <SectionLabel text="Capabilities" />
          <h2 className="text-3xl md:text-4xl font-extrabold text-slate-900 tracking-tight mb-12 max-w-2xl leading-tight">
            What We Deliver
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-slate-100 border border-slate-100 rounded-2xl overflow-hidden">
            {features.map((f) => (
              <div key={f.title} className="bg-white p-6 flex gap-4 hover:bg-slate-50 transition-colors">
                <div className="flex-shrink-0 w-8 h-8 rounded-lg bg-indigo-100 flex items-center justify-center">
                  <span className="text-[10px] font-black text-indigo-600">{f.num}</span>
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 mb-1">{f.title}</h4>
                  <p className="text-xs text-slate-500 leading-relaxed">{f.body}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Process ──────────────────────────────────────────── */}
      <section className="bg-slate-50 py-20 border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-6">
          <SectionLabel text="Methodology" />
          <h2 className="text-3xl md:text-4xl font-extrabold text-slate-900 tracking-tight mb-14 max-w-2xl leading-tight">
            How We Deliver
          </h2>
          <div className="relative">
            <div className="hidden md:block absolute top-5 left-5 right-5 h-px bg-gradient-to-r from-indigo-100 via-indigo-400 to-indigo-100" />
            <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
              {process.map((step) => (
                <div key={step.num} className="relative flex flex-col items-start md:items-center md:text-center">
                  <div className="relative z-10 w-10 h-10 rounded-full bg-white border-2 border-indigo-500 flex items-center justify-center mb-4 shadow-sm">
                    <span className="text-xs font-black text-indigo-600">{step.num}</span>
                  </div>
                  <h4 className="text-xs font-black uppercase tracking-wide text-slate-800 mb-2">{step.title}</h4>
                  <p className="text-xs text-slate-500 leading-relaxed">{step.body}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── Why Us ───────────────────────────────────────────── */}
      <section className="bg-white py-20 border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-6">
          <SectionLabel text="Why AgenticSense" />
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-14 items-start">
            <div className="lg:col-span-7">
              <h2 className="text-3xl md:text-4xl font-extrabold text-slate-900 tracking-tight mb-8 leading-tight">
                {whyUs.heading}
              </h2>
              <div className="divide-y divide-slate-100">
                {whyUs.points.map((p) => (
                  <div key={p.title} className="flex gap-4 py-5">
                    <div className="flex-shrink-0 w-2 h-2 rounded-full bg-indigo-500 mt-2 shadow-sm shadow-indigo-300" />
                    <div>
                      <h4 className="text-sm font-bold text-slate-900 mb-1">{p.title}</h4>
                      <p className="text-sm text-slate-500 leading-relaxed">{p.body}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="lg:col-span-5">
              <div className="bg-gradient-to-br from-slate-900 to-indigo-950 rounded-2xl p-8 text-white">
                <h3 className="text-lg font-extrabold mb-3">{whyUs.box.heading}</h3>
                <p className="text-sm text-slate-300 leading-relaxed mb-6">{whyUs.box.body}</p>
                <div className="space-y-3">
                  {whyUs.box.stats.map((s) => (
                    <div key={s.label} className="flex items-center justify-between bg-white/10 rounded-lg px-4 py-3">
                      <span className="text-xl font-extrabold text-indigo-300">{s.val}</span>
                      <span className="text-xs text-slate-400 font-semibold text-right max-w-[160px]">{s.label}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── FAQs ─────────────────────────────────────────────── */}
      <section className="bg-slate-50 py-20 border-b border-slate-100">
        <div className="max-w-4xl mx-auto px-6">
          <SectionLabel text="Frequently Asked Questions" />
          <h2 className="text-3xl md:text-4xl font-extrabold text-slate-900 tracking-tight mb-12 leading-tight">
            Questions We Hear Every Time
          </h2>
          <div className="divide-y divide-slate-200">
            {faqs.map((f) => (
              <details key={f.q} className="group py-5">
                <summary className="flex items-start justify-between gap-4 cursor-pointer list-none">
                  <div className="flex gap-3 items-start">
                    <span className="flex-shrink-0 w-5 h-5 rounded bg-indigo-100 flex items-center justify-center text-[9px] font-black text-indigo-600 mt-0.5">Q</span>
                    <span className="text-sm font-bold text-slate-900 leading-snug">{f.q}</span>
                  </div>
                  <span className="flex-shrink-0 text-slate-400 group-open:rotate-180 transition-transform mt-0.5 text-xs">▾</span>
                </summary>
                <p className="pl-8 pt-3 text-sm text-slate-500 leading-relaxed">{f.a}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────────── */}
      <section className="bg-white py-20 border-b border-slate-100">
        <div className="max-w-3xl mx-auto px-6 text-center">
          <div className="inline-flex items-center gap-2 bg-indigo-50 border border-indigo-100 rounded-full px-4 py-1.5 mb-6">
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
            <span className="text-xs font-bold text-indigo-700 uppercase tracking-wide">Get Started</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-extrabold text-slate-900 tracking-tight leading-tight mb-5">
            {cta.heading}
          </h2>
          <p className="text-base text-slate-500 leading-relaxed mb-10">{cta.body}</p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center mb-6">
            <Link href="#" className="inline-flex items-center justify-center gap-2 bg-indigo-600 text-white font-bold text-sm px-7 py-4 rounded-md hover:bg-indigo-700 transition-colors">
              {cta.cta1} →
            </Link>
            <Link href="#" className="inline-flex items-center justify-center gap-2 bg-white text-slate-700 font-bold text-sm px-7 py-4 rounded-md border border-slate-200 hover:border-indigo-300 hover:text-indigo-600 transition-all">
              {cta.cta2}
            </Link>
          </div>
          <p className="text-xs text-slate-400">Dubai, UAE · Karachi, Pakistan · info@agenticsense.ai · agenticsense.ai</p>
        </div>
      </section>

      {/* ── Related Services ─────────────────────────────────── */}
      <section className="bg-slate-50 py-16">
        <div className="max-w-7xl mx-auto px-6">
          <h3 className="text-xs font-black uppercase tracking-widest text-slate-400 mb-8">Related Services</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {relatedServices.map((r) => (
              <Link key={r.slug} href={r.slug} className="group bg-white rounded-xl p-6 border border-slate-200 hover:border-indigo-300 hover:shadow-md transition-all">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-black text-indigo-500 tracking-widest">{r.number}</span>
                  <span className="text-slate-300 group-hover:text-indigo-400 transition-colors text-sm">→</span>
                </div>
                <h4 className="text-sm font-bold text-slate-900 group-hover:text-indigo-700 transition-colors leading-snug">{r.title}</h4>
              </Link>
            ))}
          </div>
        </div>
      </section>

    </main>
  );
}